define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{
		url: '/implicit/PiQuest'
	});


	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
                noSubmit:true,
                required:true, 
		numericValues:true, 
          answers: [
                 {text: 'Strongly agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                 {text: 'Slightly disagree',value:3},
                 {text: 'Disagree',value:2},
                 {text: 'Strongly disagree',value:1}
               ]
		}]);
	
	    API.addQuestionsSet('Continue', [
		{type: 'selectOne',
		autoSubmit: true,
		required:true, 
                noSubmit:true,
		numericValues:true, 
          answers: [
                 {text: 'Click here or Submit below to begin',value:1}
                 ]
		}]);
	
        
    API.addPagesSet('progressBar', [
	{progressBar: 'To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);

	
		
API.addSequence([

	{inherit: 'progressBar',
         questions: [
            {inherit: 'Continue',
               name: 'instruct',
               stem:'<h4></b>For the following questions, think about how much you have a personal responsibility or moral obligation to intervene or help ensure the welfare for the different types of people.</h4><br>'
               }]},
         
{mixer:'random',data:[  
     
	{mixer:'wrapper',data:[
	    {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'familyob1',
               required: true,
               stem:'If one of my <b>family members</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'familyob2',
               required: true,
               stem:'If the welfare of one of my <b>family members</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},

	{mixer:'wrapper',data:[
	    {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'closefriendob1',
               required: true,
               stem:'If one of my <b>close friends</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'closefriendob2',
               required: true,
               stem:'If the welfare of one of my <b>close friends</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
         
    {mixer:'wrapper',data:[
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'partnerob1',
               required: true,
               stem:'If my <b>romantic partner or spouse</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'partnerob2',
               required: true,
               stem:'If the welfare of my <b>romantic partner or spouse</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
     
     {mixer:'wrapper',data:[    
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'citizenob1',
               required: true,
               stem:'If a <b>citizen of my country</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'citizenob2',
               required: true,
               stem:'If the welfare of a <b>citizen of my country</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
               
     
     {mixer:'wrapper',data:[    
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'neighborob1',
               required: true,
               stem:'If <b>somebody from my neighborhood</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'neighborob2',
               required: true,
               stem:'If the welfare of <b>somebody from my neighborhood</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
     
     {mixer:'wrapper',data:[    
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'coworkerob1',
               required: true,
               stem:'If one of my <b>co-workers</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'coworkerob2',
               required: true,
               stem:'If the welfare of one of my <b>co-workers</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
      
      {mixer:'wrapper',data:[   
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'foreignob1',
               required: true,
               stem:'If a <b>foreign citizen</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'foreignob2',
               required: true,
               stem:'If the welfare of a <b>foreign citizen</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
        
        {mixer:'wrapper',data:[ 
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'religob1',
               required: true,
               stem:'If <b>somebody with different religious beliefs</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'religob2',
               required: true,
               stem:'If the welfare of <b>somebody with different religious beliefs</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
        
        {mixer:'wrapper',data:[ 
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'leaderob1',
               required: true,
               stem:'If <b>the President, Prime Minister, or leader of my country</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'leaderob2',
               required: true,
               stem:'If the welfare of <b>the President, Prime Minister, or leader of my country</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]}
               ]},
        
        {mixer:'wrapper',data:[       
               {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'soldierob1',
               required: true,
               stem:'If <b>a soldier for my country</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'soldierob2',
               required: true,
               stem:'If the welfare of <b>a soldier for my country</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
       
       {mixer:'wrapper',data:[ 
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'charityob1',
               required: true,
               stem:'If <b>a charity worker</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'charityob2',
               required: true,
               stem:'If the welfare of <b>a charity worker</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
         
         {mixer:'wrapper',data:[
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'homob1',
               required: true,
               stem:'If <b>a homosexual person</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'homob2',
               required: true,
               stem:'If the welfare of <b>a homosexual person</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
      
      {mixer:'wrapper',data:[   
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'mentob1',
               required: true,
               stem:'If <b>a mentally challenged person</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'mentob2',
               required: true,
               stem:'If the welfare of <b>a mentally challenged person</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
         
       
       {mixer:'wrapper',data:[  
         	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'refugeeob1',
               required: true,
               stem:'If <b>a refugee</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
      
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'refugeeob2',
               required: true,
               stem:'If the welfare of <b>a refugee</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
        
        {mixer:'wrapper',data:[       
               	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'murderob1',
               required: true,
               stem:'If <b>a murderer</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'murderob2',
               required: true,
               stem:'If the welfare of <b>a murderer</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},
        
        {mixer:'wrapper',data:[       
             	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'terrorob1',
               required: true,
               stem:'If <b>a terrorist</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'terrorob2',
               required: true,
               stem:'If the welfare of <b>a terrorist</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]},

{mixer:'wrapper',data:[
    	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'molestob1',
               required: true,
               stem:'If <b>a child molester</b> is in need, it is my personal responsibility to help.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'molestob2',
               required: true,
               stem:'If the welfare of <b>a child molester</b> is threatened, I have a moral obligation or duty to do something about it.</h4><br>'
               }]}
               ]}

    ]);

 
return API.script;
});






















