define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest'});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
		required:true, 
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1}
               ]}],
          
	API.addQuestionsSet('singleChoiceR', [
		{type: 'selectOne',
		autoSubmit: true,
		required:true, 
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:1},
                 {text: 'Agree',value:2},
                 {text: 'Slightly Agree',value:3},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:5},
                   {text:'Disagree',value:6},
                  {text:'Strongly Disagree',value:7}
               ]}]),
	
	

                    API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you agree or disagree. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]));


	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoiceR',
               name: 'mosaffective1R',
               required: true,
               stem: "Unethical behavior does not bother me."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'mosaffective2',
               required: true,
               stem: "It upsets me when people do something unethical."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'mosaffective3',
               required: true,
               stem: "I tend to get upset when I see someone cheating."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'mosaffective4',
               required: true,
               stem: "When I think of people getting hurt it makes me upset."}]},

	       
        {inherit: 'progressBar',
         questions: [
	{inherit: 'singleChoice',
		name: 'mosaffective5',
		required: true,
               stem: "I cringe when I see someone get injured."}]},


        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'mosaffective6',
               required: true,
               stem: "I tend to feel strong emotions when someone behaves unethically."}]},
	 

        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'mosaffective7',
               required: true,
               stem: "Other people's pain is very real to me."}]}
	 

    ]}]);

 
return API.script;
});








