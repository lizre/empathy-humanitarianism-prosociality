define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'More than once a week',value:7},
                 {text: 'About once a week',value:6},
                 {text: 'About twice a month',value:5},
                 {text: 'About once a month',value:4},
                  {text:'3-6 times',value:3},
                   {text:'Once or twice',value:2},
                  {text:'Never',value:1},
               ]
		}]);
	
	

            API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how often you have done each behavior. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);

	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'issaltruism1',
               stem: "In the last 12 months, how often have you helped someone outside of your household with housework or shopping?"}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'issaltruism2',
               stem: "In the last 12 months, how often have you lent money to another person?"}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'issaltruism3',
               stem: "In the last 12 months, how often have you spent time talking with someone who was a bit down or depressed?"}]},
	 
         {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism1',
               stem: "In the last 12 months, how often have you donated blood?"}]},
	
         {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism2',
               stem: "In the last 12 months, how often have you given food or money to a homeless person?"}]},

                        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism3',
               stem: "In the last 12 months, how often have you allowed a stranger to go ahead of you in line?"}]},

                        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism4',
               stem: "In the last 12 months, how often have you done volunteer work for a charity?"}]},

                        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism5',
               stem: "In the last 12 months, how often have you given money to a charity?"}]},

                        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism6',
               stem: "In the last 12 months, how often have you offered your seat on a bus or in a public place to a stranger who was standing?"}]},

               
             {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism7',
               stem: "In the last 12 months, how often have you looked after a person's plants, mail, or pets while they were away?"}]},

               
                      {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism8',
               stem: "In the last 12 months, how often have you carried a stranger's belongings, like groceries, a suitcase, or shopping bag?"}]},


                      {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism9',
               stem: "In the last 12 months, how often have you given directions to a stranger?"}]},


                      {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'gssaltruism10',
               stem: "In the last 12 months, how often have you let someone you didn't know well borrow an item of some value like dishes or tools?"}]},


        
    ]},]);

 
return API.script;
});
