define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Extremely important',value:5},
                 {text: 'Very important',value:4},
                 {text: 'Somewhat important',value:2},
                 {text: 'Slightly important',value:1},
                 {text: 'Not important',value:0},
                  ]
		}]);
	
            API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you agree or disagree. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);


		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'univ1',
               stem: "How important is universalism (understanding, appreciation and tolerance for all people) as a life-guiding principle for you?"}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'univ2',
               stem: "How important is broad-mindedness as a life-guiding principle for you?"}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'univ3',
               stem: "How important is beauty of nature and arts as a life-guiding principle for you?"}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'univ4',
               stem: "How important is social justice as a life-guiding principle for you?"}]},
	 

    ]},]);

 
return API.script;
});
