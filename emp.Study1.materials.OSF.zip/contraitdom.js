define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1},
               ]
		}]);
	


            API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you agree or disagree. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);

	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'contraitdom1',
               stem: "Groups at the bottom are just as deserving as groups at the top."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'contraitdom2',
               stem: "No one group should dominate in society."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'contraitdom3',
               stem: "Groups at the bottom should not have to stay in their place. "}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'contraitdom4',
               stem: "Group dominance is a poor principle."}]},
	 

    ]},]);

 
return API.script;
});
