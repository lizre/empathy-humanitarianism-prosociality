define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{
		url: '/implicit/PiQuest',
	});

	API.addQuestionsSet('genpref', [
		{
			type: 'selectOne',
			autoSubmit:true,
			noSubmit:true,
          answers: [
				 {text:'I strongly prefer Summer to Winter.',value:3},
				 {text:'I moderately prefer Summer to Winter.',value:2},
				 {text:'I slightly prefer Summer to Winter.',value:1},
				 {text:'I like Summer and Winter equally.',value:0},
				 {text:'I slightly prefer Winter to Summer.',value:-1},
				 {text:'I moderately prefer Winter to Summer.',value:-2},
				 {text:'I strongly prefer Winter to Summer.',value:-3}
               ]
		}
	]);

	API.addPagesSet('progressBar', [
		{
			progressBar: '<%= pagesMeta.number %> out of 1',
			numbered: false,
			decline: true,
			v1style:2
		}
	]);


	API.addSequence([
			{
      	   inherit: 'progressBar',
			questions: [
            {
               inherit: 'genpref',
               name: 'att',
               stem: "Which statement best describes you?"
            }]},
		]);

	return API.script;
});