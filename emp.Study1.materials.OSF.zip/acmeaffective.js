define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1},
               ]}],
          
	API.addQuestionsSet('singleChoiceR', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:1},
                 {text: 'Agree',value:2},
                 {text: 'Slightly Agree',value:3},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:5},
                   {text:'Disagree',value:6},
                  {text:'Strongly Disagree',value:7},
               ]}]),
	
    
                        

                    API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you agree or disagree. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]));

	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'acmeaffective1',
               stem: "It makes me feel good to help someone in need."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'acmeaffective2',
               stem: "I get excited to give someone a gift that I think they will enjoy."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoiceR',
               name: 'acmeaffective3R',
               stem: "I don't worry much about hurting people's feelings."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoiceR',
               name: 'acmeaffective4R',
               stem: "I don't really care if other people feel happy."}]},

	       
        {inherit: 'progressBar',
         questions: [
	{inherit: 'singleChoiceR',
		name: 'acmeaffective5R',
               stem: "I don't really care if people are feeling depressed."}]},


        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoiceR',
               name: 'acmeaffective6R',
               stem: "Other people's feelings don't bother me at all."}]},
	 
        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'acmeaffective7',
               stem: "I feel awful when I hurt someone's feelings."}]},
	 
        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoiceR',
               name: 'acmeaffective8R',
               stem: "Other people's misfortunes don't bother me much."}]},
	 

         {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'acmeaffective9',
               stem: "If I see that I am doing something that hurts someone, I will quickly stop."}]},
	 

         {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'acmeaffective10',
               stem: "I often try to help people feel better when they are upset."}]},
	 

         {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'acmeaffective11',
               stem: "I enjoy making others happy."}]},
	 
         {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'acmeaffective12',
               stem: "People have told me that I'm insensitive."}]},

         
    ]},]);

 
return API.script;
});
