define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1},
               ]
		}]);
        
        API.addQuestionsSet('Continue', [
		{type: 'selectOne',
		autoSubmit: true,
                noSubmit:true,
		numericValues:true, 
          answers: [
                 {text: 'Click here or Submit below to begin',value:1},
                 ]
		}]);
	
	
            API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you agree or disagree. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);
	
		
API.addSequence([


         
{mixer:'random',data:[
                      
         
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'socialjustice1',
               stem: "We should all be responsible for improving the welfare of others beyond our immediate circle of friends and family."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'socialjustice2',
               stem: "It's an obligation, not a matter of personal preference, to provide for people worse off even if we're not close to them."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'socialjustice3',
               stem: "It's important for those who are better off in society to work hard to provide more resources for those who are worse off."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'socialjustice4',
               stem: "If we look after ourselves, we still need to look after others in society."}]},

  {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'socialjustice5',
               stem: "In the healthiest societies those at the top feel responsible for providing better lives for those at the bottom."}]},
               
    ]},]);

 
return API.script;
});
