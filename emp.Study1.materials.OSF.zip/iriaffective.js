define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1},
               ]}],
          
	API.addQuestionsSet('singleChoiceR', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:1},
                 {text: 'Agree',value:2},
                 {text: 'Slightly Agree',value:3},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:5},
                   {text:'Disagree',value:6},
                  {text:'Strongly Disagree',value:7},
               ]}]),
	
	


                    API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you agree or disagree. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]));


	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'iriaffective1',
               stem: "I often have tender, concerned feelings for people less fortunate than me."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoiceR',
               name: 'iriaffective2R',
               stem: "Sometimes I don't feel very sorry for other people when they are having problems."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'iriaffective3',
               stem: "When I see someone being taken advantage of, I feel kind of protective towards them."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoiceR',
               name: 'iriaffective4R',
               stem: "Other people's misfortunes do not usually disturb me a great deal."}]},

	       
        {inherit: 'progressBar',
         questions: [
	{inherit: 'singleChoiceR',
		name: 'iriaffective5R',
               stem: "When I see someone being treated unfairly, I sometimes don't feel very much pity for them."}]},


        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'iriaffective6',
               stem: "I am often quite touched by things that I see happen."}]},
	 

        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'iriaffective7',
               stem: "I would describe myself as a pretty soft-hearted person."}]},
	 
    ]},]);

 
return API.script;
});
