define(['questAPI'], function(Quest){
	var API = new Quest();
	// ### Questions
	API.addQuestionsSet('basicNumber',
	{
		type: 'textNumber',
		autoSubmit:true,
		numericValues:true,
		required:true,
		dflt:0,
		errorMsg: {
			required: "Please type a number between 1 and 5, type '0', or click 'decline to answer'"
		}
	});

	API.addQuestionsSet({
        feedingamerica: [{
            inherit: 'basicNumber',
            name:'feedingamerica',
            stem:'<b>Feeding America</b>: a nationwide network of food banks feeding hungry Americans.'
        }],
		amerredcross: [{
			inherit: 'basicNumber',
			name:'amerredcross',
			stem:'<b>American Red Cross</b>: provides emergency assistance and disaster relief inside the United States.'
		}],
		migrantaid: [{
			inherit: 'basicNumber',
			name:'migrantaid',
			stem:'<b>Migrant Offshore Aid Station</b>: preventing loss of life to Middle Eastern refugees and migrants in distress at sea.'
		}],
        icafrica: [{
			inherit: 'basicNumber',
			name:'icafrica',
			stem:'<b>International Charity for Africa</b>: offers small loans to poor self-employed Africans to get their children out of extreme poverty.'
        }],

        total: [{
            regenerateTemplate: true,
            stem: 'Total: <%= questions.feedingamerica ? (questions.feedingamerica.response || 0) + (questions.amerredcross.response || 0) + (questions.migrantaid.response || 0) + (questions.icafrica.response || 0) : 0 %> (Must be 5)',
            name: 'total',
            type: 'info'
        }],
		 
        instr: [{
            regenerateTemplate: true,
            stem: '<div align="center"><b>This study is for charity!</b></align><div align="left"><p><p>When the study ends, the research team will split $50 between four charities on behalf of the study participants. <b>You get to decide where the money goes!</b> Each participant has 5 votes. You may choose to donate them all to one charity, or split the credits between charities. Please use only whole numbers (i.e., 1, 2, 3, 4 and 5). At the end of the study, we will donate a portion of the $50 to each charity based on what everyone decides. <p><p>The charities are:',
            name: 'instr',
            type: 'info'
        }]
    });
	

	// ### Pages
	API.addPagesSet('basicPage',
	{
		progressBar: '',
		headerStyle : {'font-size':'1em'},
		v1style:2,
		decline:true,
		numbered: false
	});

	// ### Sequence
	API.addSequence(
	[
		{
            inherit :'basicPage',
            pageValidationText:'The total must add up to 5' ,
            pageValidation: function(){
                var questions = API.getCurrent().questions;
                return (questions.feedingamerica.response || 0) + (questions.amerredcross.response || 0) + (questions.migrantaid.response || 0) + (questions.icafrica.response || 0) === 5;
            },
            questions:[
                // always show this question
                {inherit:'instr'},
                {mixer:'random', data : [
                    {inherit:'feedingamerica'},
                    {inherit:'amerredcross'},
                    {inherit:'icafrica'}
                ]},
                {inherit:'migrantaid'},
                {inherit:'total'}
            ]
        }
	]);

	/**
	Return the script to piquest's god, or something of that sort.
	**/
	return API.script;
});
		


















