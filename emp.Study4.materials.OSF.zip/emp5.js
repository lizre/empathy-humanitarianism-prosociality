define(['managerAPI'], function(Manager){

// This code is responsible for styling the piQuest tasks as panels (like piMessage)
	// Don't touch unless you know what you're doing
	var API = new Manager();
	API.addSettings('skin', 'demo');
	API.addSettings('skip',true);

	API.setName('mgr');
	API.addGlobal({baseURL : '/implicit/user/uflliz/emp5/images/'});
	API.addTasksSet({
		instructions: [{type:'message', buttonText:'Continue'}], 
		
		consent : [{inherit:'instructions', name:'consent', templateUrl: 'consent.jst', title:'Consent', 
			piTemplate:true, header:'Consent Agreement: Implicit Social Cognition on the Internet'}],
		
	
		realstart : [{
			inherit:'instructions', name:'realstart', templateUrl: 'realstart.jst', title:'Instructions', 
			piTemplate:true
		}], 


		instructions5 : [{
			inherit:'instructions', name:'instructions5', templateUrl: 'instructions5.jst', piTemplate:true}], 

		univ: [{type: 'quest', name: 'univ', scriptUrl: 'univ.js'}],
		
			
		mosaffective: [{type: 'quest', name: 'mosaffective', scriptUrl: 'mosaffective.js'}],
		
	iriaffective: [{type: 'quest', name: 'iriaffective', scriptUrl: 'iriaffective.js'}],
		
		
	acmeaffective: [{type: 'quest', name: 'acmeaffective', scriptUrl: 'acmeaffective.js'}],
	
		obligation: [{type: 'quest', name: 'obligation', scriptUrl: 'obligation.js'}],
		
		socialjustice: [{type: 'quest', name: 'socialjustice', scriptUrl: 'socialjustice.js'}],
		
		  
		instiatrace: [{inherit:'instructions', name:'iatinstrace', templateUrl: 'instiatrace.jst', title:'IAT Instructions',
			      piTemplate:true, header:'Implicit Association Test'}],
                    
		
		iatrace: [{type: 'pip', name: 'iatrace', version: '0.3', scriptUrl: 'iatrace.js'}], 
		  
	
		debriefing : [{type:'message',name:'lastpage', templateUrl: 'debriefing.jst', piTemplate:'debrief', last:true}]
});

	

	API.addSequence([
	
		
{inherit:'consent'},
	
{inherit:'realstart'},
		
	{mixer:'random', data : [
		
				{inherit:'univ'},
				{inherit:'acmeaffective'},
				{inherit:'mosaffective'},
				{inherit:'iriaffective'},
		{inherit:'socialjustice'}
		
	]},
	
	{inherit:'instructions5'},	
	
		{inherit:'obligation'},

	{inherit:'instiatrace'},
	{inherit:'iatrace'},	

	{inherit:'debriefing'}

		
]);


		
	return API.script;
});


















