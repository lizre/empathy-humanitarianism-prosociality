define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{
		url: '/implicit/PiQuest'
	});


	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
                noSubmit:true,
		numericValues:true, 
          answers: [
                 {text: 'Inner circle',value:3},
                 {text: 'Outer circle',value:2},
                 {text: 'Fringes of concern',value:1},
                 {text: 'Outside the moral boundary',value:0}
               ]
		}]);
	
	    API.addQuestionsSet('Continue', [
		{type: 'selectOne',
		autoSubmit: true,
                noSubmit:true,
		numericValues:true, 
          answers: [
                 {text: 'Click here or Submit below to begin',value:1}
                 ]
		}]);
	
        
    API.addPagesSet('progressBar', [
	{progressBar: 'To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);

	
		
API.addSequence([

	{inherit: 'progressBar',
         questions: [
            {inherit: 'Continue',
               name: 'moralexpaninstruct',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>For the next several questions, please use the above guidelines to indicate what you consider to be the moral standing of the person.</h4><br>'
               }]},
         
{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanfamily',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of one of your <b>family members</b>.</h4><br>'
               }]},
            
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanclosefriend',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of one of your <b>close friends</b>.</h4><br>'
               }]},

	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanpartner',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of your <b>romantic partner or spouse</b>.</h4><br>'
               }]},

 
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpancitizen',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of a <b>citizen of your country</b>.</h4><br>'
               }]},
         
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanneighbor',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>somebody from your neighborhood</b>.</h4><br>'
               }]},
         
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpancoworker',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of one of your <b>co-workers</b>.</h4><br>'
               }]},
         

	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanforeign',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of a <b>foreign citizen</b>.</h4><br>'
               }]},


	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanparty',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of a <b>member of an opposing political party</b>.</h4><br>'
               }]},


	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanrelig',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>somebody with different religious beliefs</b>.</h4><br>'
               }]},




	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanleader',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>the President, Prime Minister, or leader of your country</b>.</h4><br>'
               }]},

               
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpansoldier',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a soldier for your country</b>.</h4><br>'
               }]},
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpancharity',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a charity worker</b>.</h4><br>'
               }]},
         
         
         
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanhom',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a homosexual person</b>.</h4><br>'
               }]},
         
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanment',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a mentally challenged person</b>.</h4><br>'
               }]},
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanhrefugee',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a refugee</b>.</h4><br>'
               }]},
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanmurder',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a murderer</b>.</h4><br>'
               }]},
         
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanterror',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a terrorist</b>.</h4><br>'
               }]},

	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'moralexpanmolest',
               stem:'<img src="/implicit/user/uflliz/emp2/images/moralexpan.png" height="400"> <br><br><h4>Please indicate what you consider to be the moral standing of <b>a child molester</b>.</h4><br>'
               }]}

    ]}]);

 
return API.script;
});


